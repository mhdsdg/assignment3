package Models;

public record Result(boolean success, String message) {
}
