
/*
  Just Start the program from here and do nothing else here.
 */

import views.AppView;

public class Main {
    public static void main(String[] args) {
        new AppView().run();
}
}
