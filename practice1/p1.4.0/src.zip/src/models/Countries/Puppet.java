package models.Countries;

public class Puppet {
    public Countries country;
    public Puppet(Countries country) {
        this.country = country;
    }
}
