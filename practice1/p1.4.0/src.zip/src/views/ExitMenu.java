package views;

import java.util.Scanner;

public class ExitMenu extends AppMenu{
    public void check(Scanner sc) {

    }
}
