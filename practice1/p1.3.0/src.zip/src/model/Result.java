package model;

public record Result (boolean isSuccessful , String message) {

}
