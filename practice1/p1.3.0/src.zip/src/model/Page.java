package model;

public class Page {
    public String information;
    public Page(String information) {
        this.information = information;
    }
}
