package view;

import java.awt.event.ActionListener;
import java.util.Scanner;
import java.util.regex.Matcher;

public class ExitMenu implements AppMenu {

    public void check(Scanner scanner) {
        String input = scanner.nextLine();
        Matcher matcher ;
    }}
