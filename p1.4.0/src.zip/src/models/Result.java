package models;

public record Result(boolean isSuccessful, String message) {
}
