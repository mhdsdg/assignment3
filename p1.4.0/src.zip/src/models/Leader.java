package models;

public class Leader {
    public String name;
    public String ideology;

    public Leader(String name, String ideology) {
        this.name = name;
        this.ideology = ideology;
    }
}
